valid_email = "aamalex2dd1@gee.com"
valid_password = "Aws12345"

invalid_email = "njnkjn2@njn.ru"
invalid_password = "nkjnkjlknm"